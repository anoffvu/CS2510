// edge of a graph
class Edge {
  GamePiece fromNode;
  GamePiece toNode;
  int weight;
}
